# CamMirror Pro (Android APK)

1. Upload all files in this folder to your GitHub repository.
2. Go to the **Actions** tab and run **Build CamMirror Pro APK** (or it runs automatically on push).
3. Download **CamMirrorPro-debug-apk** from the workflow artifacts and install on your Android device.
