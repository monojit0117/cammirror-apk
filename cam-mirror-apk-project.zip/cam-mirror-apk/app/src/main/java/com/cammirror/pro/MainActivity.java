package com.cammirror.pro;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private WebView webView;
    private volatile boolean serverRunning = true;
    private volatile boolean sessionActive = false;
    private volatile String cameraIp = "192.168.122.1";
    private volatile String cameraPort = "8080";
    private volatile String cameraProtocol = "Sony JSON-RPC";
    private volatile String liveviewUrl = null;
    private ServerSocket serverSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        startLocalBridgeServer();
        startKeepAliveThread();

        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        serverRunning = false;
        sessionActive = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    private String sonyRpc(String ip, String port, String method, JSONArray params, int timeoutMs) throws Exception {
        URL url = new URL("http://" + ip + ":" + port + "/sony/camera");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(timeoutMs);
        conn.setReadTimeout(timeoutMs);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");

        JSONObject payload = new JSONObject();
        payload.put("method", method);
        payload.put("params", params != null ? params : new JSONArray());
        payload.put("id", 1);
        payload.put("version", "1.0");

        byte[] out = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(out);
        }

        InputStream is = conn.getResponseCode() >= 400 ? conn.getErrorStream() : conn.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        conn.disconnect();
        return sb.toString();
    }

    private void startKeepAliveThread() {
        new Thread(() -> {
            while (serverRunning) {
                try {
                    Thread.sleep(3000);
                    if (sessionActive && cameraProtocol.contains("Sony")) {
                        JSONArray p = new JSONArray();
                        p.put(false);
                        sonyRpc(cameraIp, cameraPort, "getEvent", p, 5000);
                    }
                } catch (Exception ignored) {}
            }
        }).start();
    }

    private void startLocalBridgeServer() {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(18080, 16, InetAddress.getByName("127.0.0.1"));
                while (serverRunning) {
                    final Socket client = serverSocket.accept();
                    new Thread(() -> handleClient(client)).start();
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void handleClient(Socket client) {
        try {
            BufferedInputStream in = new BufferedInputStream(client.getInputStream());
            OutputStream out = client.getOutputStream();

            ByteArrayOutputStream headerBuf = new ByteArrayOutputStream();
            int prev = -1, curr;
            int contentLength = 0;
            String firstLine = null;

            StringBuilder lineBuilder = new StringBuilder();
            while ((curr = in.read()) != -1) {
                if (curr == '\n') {
                    String line = lineBuilder.toString().replace("\r", "");
                    lineBuilder.setLength(0);
                    if (firstLine == null) {
                        firstLine = line;
                    } else if (line.isEmpty()) {
                        break;
                    } else if (line.toLowerCase().startsWith("content-length:")) {
                        contentLength = Integer.parseInt(line.substring(15).trim());
                    }
                } else {
                    lineBuilder.append((char) curr);
                }
            }
            if (firstLine == null) {
                client.close();
                return;
            }

            String[] parts = firstLine.split(" ");
            String method = parts.length > 0 ? parts[0] : "GET";
            String path = parts.length > 1 ? parts[1].split("\\?")[0] : "/";

            if ("OPTIONS".equals(method)) {
                sendJson(out, 200, "{}");
                client.close();
                return;
            }

            byte[] bodyBytes = new byte[contentLength];
            int readTotal = 0;
            while (readTotal < contentLength) {
                int r = in.read(bodyBytes, readTotal, contentLength - readTotal);
                if (r < 0) break;
                readTotal += r;
            }
            String bodyStr = new String(bodyBytes, StandardCharsets.UTF_8);

            if ("/api/ping".equals(path)) {
                sendJson(out, 200, "{\"ok\":true,\"active\":" + sessionActive + "}");
                client.close();
                return;
            }

            if ("/api/connect".equals(path) && "POST".equals(method)) {
                JSONObject req = new JSONObject(bodyStr.isEmpty() ? "{}" : bodyStr);
                cameraIp = req.optString("ip", "192.168.122.1").trim();
                cameraPort = req.optString("port", "8080").trim();
                cameraProtocol = req.optString("protocol", "Sony JSON-RPC");
                sessionActive = true;
                liveviewUrl = null;

                JSONArray apis = new JSONArray();
                if (cameraProtocol.contains("Sony")) {
                    try { sonyRpc(cameraIp, cameraPort, "startRecMode", new JSONArray(), 6000); } catch (Exception ignored) {}
                    try {
                        String lvRes = sonyRpc(cameraIp, cameraPort, "startLiveview", new JSONArray(), 8000);
                        JSONObject lvJson = new JSONObject(lvRes);
                        if (lvJson.has("result")) {
                            liveviewUrl = lvJson.getJSONArray("result").getString(0);
                        }
                    } catch (Exception e) {
                        sessionActive = false;
                        JSONObject err = new JSONObject();
                        err.put("ok", false);
                        err.put("error", "Camera unreachable at " + cameraIp + ":" + cameraPort);
                        sendJson(out, 502, err.toString());
                        client.close();
                        return;
                    }
                    try {
                        String apiRes = sonyRpc(cameraIp, cameraPort, "getAvailableApiList", new JSONArray(), 5000);
                        JSONObject apiJson = new JSONObject(apiRes);
                        if (apiJson.has("result")) apis = apiJson.getJSONArray("result").getJSONArray(0);
                    } catch (Exception ignored) {}
                }

                JSONObject resp = new JSONObject();
                resp.put("ok", true);
                resp.put("liveview", liveviewUrl != null);
                resp.put("availableApis", apis);
                sendJson(out, 200, resp.toString());
                client.close();
                return;
            }

            if ("/api/logout".equals(path) && "POST".equals(method)) {
                boolean wasActive = sessionActive;
                sessionActive = false;
                liveviewUrl = null;
                if (wasActive && cameraProtocol.contains("Sony")) {
                    try { sonyRpc(cameraIp, cameraPort, "stopLiveview", new JSONArray(), 4000); } catch (Exception ignored) {}
                    try { sonyRpc(cameraIp, cameraPort, "stopRecMode", new JSONArray(), 4000); } catch (Exception ignored) {}
                }
                sendJson(out, 200, "{\"ok\":true,\"disconnected\":true}");
                client.close();
                return;
            }

            if ("/api/rpc".equals(path) && "POST".equals(method)) {
                if (!sessionActive) {
                    sendJson(out, 403, "{\"ok\":false,\"error\":\"Not connected\"}");
                    client.close();
                    return;
                }
                JSONObject req = new JSONObject(bodyStr);
                String rpcMethod = req.getString("method");
                JSONArray rpcParams = req.optJSONArray("params");
                try {
                    String raw = sonyRpc(cameraIp, cameraPort, rpcMethod, rpcParams, 8000);
                    JSONObject parsed = new JSONObject(raw);
                    JSONObject resp = new JSONObject();
                    if (parsed.has("error")) {
                        JSONArray eArr = parsed.getJSONArray("error");
                        resp.put("ok", false);
                        resp.put("sonyError", eArr.length() > 1 ? eArr.getString(1) : eArr.toString());
                    } else {
                        resp.put("ok", true);
                    }
                    resp.put("response", parsed);
                    sendJson(out, 200, resp.toString());
                } catch (Exception e) {
                    JSONObject err = new JSONObject();
                    err.put("ok", false);
                    err.put("error", e.getMessage());
                    sendJson(out, 502, err.toString());
                }
                client.close();
                return;
            }

            if ("/api/liveview".equals(path)) {
                streamLiveview(out);
                client.close();
                return;
            }

            sendJson(out, 404, "{\"error\":\"Not found\"}");
            client.close();
        } catch (Exception ignored) {
            try { client.close(); } catch (Exception ignored2) {}
        }
    }

    private void streamLiveview(OutputStream out) throws Exception {
        String hdr = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                "Cache-Control: no-store\r\n" +
                "Access-Control-Allow-Origin: *\r\n\r\n";
        out.write(hdr.getBytes(StandardCharsets.US_ASCII));
        out.flush();

        while (sessionActive) {
            if (liveviewUrl == null) {
                Thread.sleep(400);
                continue;
            }
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(liveviewUrl).openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(20000);
                InputStream upstream = conn.getInputStream();

                byte[] common = new byte[8];
                byte[] payloadHeader = new byte[128];

                while (sessionActive) {
                    if (!readExact(upstream, common, 8)) break;
                    if ((common[0] & 0xFF) != 0xFF) continue;
                    int payloadType = common[1] & 0xFF;
                    if (!readExact(upstream, payloadHeader, 128)) break;

                    int jpegSize = ((payloadHeader[4] & 0xFF) << 16)
                            | ((payloadHeader[5] & 0xFF) << 8)
                            | (payloadHeader[6] & 0xFF);
                    int padSize = payloadHeader[7] & 0xFF;

                    byte[] jpeg = new byte[jpegSize];
                    if (!readExact(upstream, jpeg, jpegSize)) break;
                    if (padSize > 0) {
                        byte[] pad = new byte[padSize];
                        readExact(upstream, pad, padSize);
                    }

                    if (payloadType == 0x01) {
                        out.write("--frame\r\nContent-Type: image/jpeg\r\n\r\n".getBytes(StandardCharsets.US_ASCII));
                        out.write(jpeg);
                        out.write("\r\n".getBytes(StandardCharsets.US_ASCII));
                        out.flush();
                    }
                }
            } catch (Exception e) {
                if (e.getMessage() != null && e.getMessage().contains("Broken pipe")) return;
                Thread.sleep(600);
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
    }

    private boolean readExact(InputStream is, byte[] buf, int len) throws Exception {
        int off = 0;
        while (off < len) {
            int r = is.read(buf, off, len - off);
            if (r < 0) return false;
            off += r;
        }
        return true;
    }

    private void sendJson(OutputStream out, int code, String json) throws Exception {
        byte[] b = json.getBytes(StandardCharsets.UTF_8);
        String hdr = "HTTP/1.1 " + code + " OK\r\n" +
                "Content-Type: application/json\r\n" +
                "Content-Length: " + b.length + "\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Access-Control-Allow-Headers: Content-Type\r\n" +
                "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n" +
                "Cache-Control: no-store\r\n\r\n";
        out.write(hdr.getBytes(StandardCharsets.US_ASCII));
        out.write(b);
        out.flush();
    }
}
