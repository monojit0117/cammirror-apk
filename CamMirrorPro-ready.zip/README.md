# CamMirror Pro

Android WebView app. The whole UI is in `app/src/main/assets/index.html`.

## Get the APK from GitHub
1. Upload ALL files of this project to the repository root (including the hidden `.github` folder and `app/debug.keystore`).
2. Open the **Actions** tab, wait for **Build CamMirror Pro APK** to finish (green check).
   If it did not start, press **Run workflow**.
3. Open the finished run, download **CamMirrorPro-APK** under *Artifacts*, unzip it, install `app-debug.apk`.

## Notes
- If the `.github` folder is missing in the repo, create the file `.github/workflows/build-apk.yml` on GitHub (Add file > Create new file) and paste the content from this project.
- The APK is always signed with the same key, so new builds install over old ones.
  The first time, uninstall any older CamMirror Pro that came from another build.
- To confirm you have the new UI: Menu > About CamMirror Pro shows "Version 15.0".
